import xbmcaddon

MainBase = 'http://pastebin.com/raw/PCzP3AhC'
addon = xbmcaddon.Addon('plugin.video.davidev')